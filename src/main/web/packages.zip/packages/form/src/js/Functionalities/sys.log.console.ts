/**
 * Provides the {@link Sys_Log_Console.functionality }.
 *
 * @remarks
 * Maintainer: Callari, Salvatore (Salvatore.Callari@Ansbach.de) */
// biome-ignore lint/complexity/noStaticOnlyClass: Proactive Design
export class Sys_Log_Console {
  /**
   * Logs the "data" to the console.
   *
   * Config Parameter:
   *  - DATA: The data to log to the console.
   *
   * @param toLoad    Provided by the CodBi.
   * @param toProcess Provided by the CodBi. */
  public static functionality(toLoad: { [key: string]: unknown }, toProcess: Element): void {
    console.log("----- CodBi - Logger START -----");
    console.log(toLoad.data);
    console.log("----- CodBi - Logger END -----");
  }
  // #region Initialization
  /**
   * States whether this {@link Sys_Log_Console } was successfully registered
   * via {@link CodbiGlobal.registerFunctionality } with the CodBi and performs the registration upon class usage.*/
  public static registered: boolean = (() => {
    return window.codbi.registerFunctionality("Sys.Log.Console", Sys_Log_Console.functionality);
  })();
  // #endregion Initialization
}
